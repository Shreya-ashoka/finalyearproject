import streamlit as st
import os
import sqlite3
from hashlib import sha256
import base64
import PyPDF2
import docx
from langchain_core.prompts import ChatPromptTemplate
from langchain_groq import ChatGroq
import time

# Page configuration
st.set_page_config(page_title="LexAssist", layout="wide")

# Custom CSS
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
    
    body {
        font-family: 'Poppins', sans-serif;
        background-color: white;
        color: #333;
    }
    
    .main-header {
        font-size: 3rem;
        font-weight: 600;
        color: #1E88E5;
        text-align: center;
        margin-bottom: 1rem;
    }
    
    .sub-header {
        font-size: 1.2rem;
        color: #555;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .stButton > button {
        background-color: #1E88E5;
        color: white;
        font-weight: 600;
        padding: 1rem;
        border-radius: 5px;
        border: none;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        background-color: #1565C0;
    }
    
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea {
        border-radius: 5px;
        border: 1px solid #B0BEC5;
    }
    
    .stTabs > div > div > button {
        font-size: 50px;
        font-weight: bold;
        transition: all 0.3s ease;
    }
    
    .stTabs > div > div > button:hover {
        background-color: #E3F2FD;
    }
    
    .stTabs > div > div > button[data-baseweb="tab"][aria-selected="true"] {
        border-bottom: 3px solid #1E88E5;
    }
    
    #logout-button {
        position: absolute;
        top: 1rem;
        left: 1rem;
    }
    
    #logout-button > button {
        background-color: #1E88E5;
        color: white;
        font-weight: 600;
        padding: 1rem;
        border-radius: 5px;
        border: none;
        transition: all 0.3s ease;
    }
    
    #logout-button > button:hover {
        background-color: #1565C0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "user_id" not in st.session_state:
    st.session_state.user_id = None
if "username" not in st.session_state:
    st.session_state.username = ""

# Database setup
conn = sqlite3.connect('user_profiles.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS user_profiles
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              user_id INTEGER,
              query TEXT,
              response TEXT,
              FOREIGN KEY(user_id) REFERENCES users(id))''')
c.execute('''CREATE TABLE IF NOT EXISTS users
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
              username TEXT,
              email TEXT UNIQUE,
              password TEXT)''')

# Groq API setup
groq_api_key = os.getenv('GROQ_API_KEY', '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')
if not groq_api_key:
    st.error("Groq API key not found. Please set the GROQ_API_KEY environment variable.")
else:
    chat = ChatGroq(temperature=0, model="llama3-70b-8192", api_key=groq_api_key)
    llm = ChatGroq(model="llama3-8b-8192", api_key=groq_api_key)

# Chat prompts
system_classification = "You are an intelligent assistant that classifies and extracts meaningful data from legal documents. Your task is to understand and categorize the document content and extract crucial details such as the type of document, involved parties, case number, and legal provisions cited."
human_classification = "Classify and extract key details from this legal document: {text}. Determine the document type and identify important information such as involved parties and legal references."
prompt_classification = ChatPromptTemplate.from_messages([("system", system_classification), ("human", human_classification)])

system_legal = "You are an intelligent legal assistant who provides legal advice."
human_legal = "{text}"
prompt_legal_advice = ChatPromptTemplate.from_messages([("system", system_legal), ("human", human_legal)])

system_doc_gen = "You are an intelligent assistant for document generation."
human_doc_gen = "{text}"
prompt_doc_gen = ChatPromptTemplate.from_messages([("system", system_doc_gen), ("human", human_doc_gen)])

system_metadata = "You are an intelligent assistant for extracting metadata from legal documents."
human_metadata = "Extract the following metadata from this document: {text}"
prompt_metadata = ChatPromptTemplate.from_messages([("system", system_metadata), ("human", human_metadata)])

# Helper functions
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Logout function
def logout():
    st.session_state.logged_in = False
    st.session_state.user_id = None
    st.session_state.username = ""
    st.success("Logged out successfully.")
    time.sleep(1)
    st.rerun()

# Main App
st.markdown('<h1 class="main-header">LexAssist</h1>', unsafe_allow_html=True)
st.markdown('<p class="sub-header">AI-Powered Legal Assistance</p>', unsafe_allow_html=True)

# Authentication
if not st.session_state.logged_in:
    tab1, tab2 = st.tabs(["Login", "Sign Up"])
    
    with tab1:
        with st.form("login_form"):
            st.subheader("Welcome Back!")
            login_email = st.text_input("Email", key="login_email")
            login_password = st.text_input("Password", type="password", key="login_password")
            login_button = st.form_submit_button("Login")
            
            if login_button:
                if login_email and login_password:
                    with st.spinner("Logging in..."):
                        time.sleep(1)  # Simulating login process
                        hashed_password = hash_password(login_password)
                        c.execute("SELECT id, username FROM users WHERE email=? AND password=?", (login_email, hashed_password))
                        user = c.fetchone()
                        if user:
                            user_id, username = user
                            st.session_state.logged_in = True
                            st.session_state.user_id = user_id
                            st.session_state.username = username
                            st.success(f"Welcome, {username}!")
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error("Invalid email or password.")
                else:
                    st.warning("Please fill all the fields.")
    
    with tab2:
        with st.form("signup_form"):
            st.subheader("Create an Account")
            signup_username = st.text_input("Username")
            signup_email = st.text_input("Email", key="signup_email")
            signup_password = st.text_input("Password", type="password", key="signup_password")
            signup_button = st.form_submit_button("Sign Up")
            
            if signup_button:
                if signup_username and signup_email and signup_password:
                    with st.spinner("Creating your account..."):
                        time.sleep(1)  # Simulating account creation process
                        c.execute("SELECT * FROM users WHERE email=?", (signup_email,))
                        if c.fetchone() is not None:
                            st.error("Email already exists. Please use a different email.")
                        else:
                            hashed_password = hash_password(signup_password)
                            c.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                                      (signup_username, signup_email, hashed_password))
                            conn.commit()
                            st.success("Account created successfully! Please log in.")
                else:
                    st.warning("Please fill all the fields.")

else:
    # Logout button
    st.markdown('<div id="logout-button">', unsafe_allow_html=True)
    if st.button("Logout"):
        logout()
    st.markdown('</div>', unsafe_allow_html=True)

    tab1, tab2, tab3, tab4, tab5 = st.tabs(["Homepage", "Legal Advice", "Document Assistant", "Metadata Extraction", "History"])

    with tab1:
        st.title("Welcome to our platform!")
        st.subheader("AI-Driven Legal Assistance and Judicial Support System")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.image("images/download.jpg", use_container_width=True)
            st.markdown('<div class="icon">💬</div>', unsafe_allow_html=True)
            st.markdown('<h3 class="feature-title">Legal Advice</h3>', unsafe_allow_html=True)
            st.markdown('<p class="feature-description">Get AI-powered legal Q&A support in multiple languages.</p>', unsafe_allow_html=True)
            if st.button("Legal Advice"):
                st.session_state.page = "Legal Advice"
                st.rerun()
        
        with col2:
            st.image("images/de.png", use_container_width=True)
            st.markdown('<div class="icon">📄</div>', unsafe_allow_html=True)
            st.markdown('<h3 class="feature-title">Document Assistant</h3>', unsafe_allow_html=True)
            st.markdown('<p class="feature-description">Generate legal documents with ease using AI assistance.</p>', unsafe_allow_html=True)
            if st.button("Document Assistant"):
                st.session_state.page = "Document Assistant"
                st.rerun()
        
        with col3:
            st.image("images/md.png", use_container_width=True)
            st.markdown('<div class="icon">📊</div>', unsafe_allow_html=True)
            st.markdown('<h3 class="feature-title">Metadata Extraction</h3>', unsafe_allow_html=True)
            st.markdown('<p class="feature-description">Extract key information from legal documents automatically.</p>', unsafe_allow_html=True)
            if st.button("Metadata Extraction"):
                st.session_state.page = "Metadata Extraction"
                st.rerun()
    
    with tab2:
        st.subheader("Legal Advice Chatbot")
        language = st.selectbox("Select Language", ["English", "Hindi", "Bengali", "Tamil", "Kannada"])
        user_input = st.text_area("Enter your legal query:")

        if st.button("Get Legal Advice"):
            if user_input:
                with st.spinner("Generating legal advice..."):
                    chain = prompt_legal_advice | chat
                    response = chain.invoke({"text": f"Respond in {language}: {user_input}"})
                    st.info(response.content)
                    c.execute("INSERT INTO user_profiles (user_id, query, response) VALUES (?, ?, ?)",
                              (st.session_state.user_id, user_input, response.content))
                    conn.commit()
            else:
                st.warning("Please enter a legal query.")
        
    with tab3:
        st.subheader("Generate Legal Document")

        name = st.text_input("Enter Name")
        doc_type = st.selectbox("Select Document Type", ["Contract", "Affidavit", "Agreement"])
        date = st.date_input("Enter Date")
        content = st.text_area("Enter Document Content")

        if st.button("Generate Document"):
            if name and content:
                with st.spinner("Generating document..."):
                    prompt = f"Generate a {doc_type} for {name} dated {date} with the following content: {content}"
                    chain = prompt_doc_gen | llm
                    response = chain.invoke({"text": prompt})

                    st.success("Document generated successfully!")
                    st.text_area("Generated Document", response.content, height=300)

                    b64 = base64.b64encode(response.content.encode()).decode()
                    href = f'<a href="data:file/txt;base64,{b64}" download="{doc_type.lower()}_{name}.txt" class="btn">Download {doc_type}</a>'
                    st.markdown(href, unsafe_allow_html=True)

                    c.execute("INSERT INTO user_profiles (user_id, query, response) VALUES (?, ?, ?)",
                            (st.session_state.user_id, prompt, response.content))
                    conn.commit()
            else:
                st.warning("Please fill in all required fields.")

    with tab4:
        st.header("Legal Document Classification & Data Extraction")
        
        uploaded_file = st.file_uploader("Choose a legal document", type=["txt", "pdf", "docx"])
        
        if uploaded_file is not None:
            st.success("File successfully uploaded!")
            
            file_contents = ""
            file_extension = uploaded_file.name.split('.')[-1].lower()
            if file_extension == "txt":
                file_contents = uploaded_file.getvalue().decode("utf-8")
            elif file_extension == "pdf":
                reader = PyPDF2.PdfReader(uploaded_file)
                for page in reader.pages:
                    file_contents += page.extract_text()
            elif file_extension == "docx":
                doc = docx.Document(uploaded_file)
                for para in doc.paragraphs:
                    file_contents += para.text + "\n"
            
            with st.expander("View File Contents"):
                st.text_area("File Contents", file_contents, height=200)
            
            if st.button("Classify and Extract Data"):
                with st.spinner("Classifying and extracting data..."):
                    chain = prompt_classification | llm
                    response = chain.invoke({"text": file_contents})
                    
                    st.subheader("Extracted Data & Classification")
                    st.info(response.content)
                    
                    c.execute("INSERT INTO user_profiles (user_id, query, response) VALUES (?, ?, ?)",
                            (st.session_state.user_id, "Document Classification & Data Extraction", response.content))
                    conn.commit()
    
    with tab5:
        st.header("Your Previous Queries and Responses")
        c.execute("SELECT query, response FROM user_profiles WHERE user_id=? ORDER BY id DESC LIMIT 5", (st.session_state.user_id,))
        rows = c.fetchall()
        for i, row in enumerate(rows):
            with st.expander(f"Query {i+1}"):
                st.write(f"**Query:** {row[0]}")
                st.write(f"**Response:** {row[1]}")
        
        if st.button("Clear History"):
            with st.spinner("Clearing history..."):
                c.execute("DELETE FROM user_profiles WHERE user_id=?", (st.session_state.user_id,))
                conn.commit()
                time.sleep(1)
                st.success("History cleared successfully.")
                st.rerun()

# Close database connection
conn.close()